<?php
session_start();
include("../connection.php");
include("../function.php");

$user_data = check_slogin($con);

$program_id = $_SESSION['prog_id'];

$dataPointsy1 = array();
$dataPointsy2 = array();
$dataPointsy3 = array();
$dataPointsy4 = array();

$sql = "select * from c_map where prog_id = '$program_id'";
$query = mysqli_query($con, $sql);

$c_map = mysqli_fetch_all($query, MYSQLI_ASSOC);

$sql1 = "select prog_name from program where prog_id = '$program_id'";
$query1 = mysqli_query($con, $sql1);

$program = mysqli_fetch_assoc($query1);

$count = 0;
$isExist = [];
$isMaterials = [];
$isExistFil = [];
$isMaterialsFil = [];

$isExistEb = [];
$isMaterialsEb = [];

$isExistGr = [];
$isMaterialsGr = [];

foreach($c_map as $list) {
    $sub = $list['curricul_sub'];
    $materials = $list['materials'];
    

    $types = explode(",", $materials);

    $numberOfTypes = count($types);

    $run_sql = "SELECT *,COUNT(*),SUM(no_copies) as total FROM c_map where curricul_sub ='$sub' AND class = 'Circulation' AND prog_id = '$program_id';";
    $run_query = mysqli_query($con, $run_sql);

    $result = mysqli_fetch_assoc($run_query);
    $total = $result['total'] + $result['COUNT(*)'];

    $run_sql1 = "SELECT *,COUNT(*),SUM(no_copies) as total FROM c_map where curricul_sub ='$sub' AND class = 'Filipiniana' AND prog_id = '$program_id';";
    $run_query1 = mysqli_query($con, $run_sql1);

    $result1 = mysqli_fetch_assoc($run_query1);
    $total1 = $result1['total'] + $result1['COUNT(*)'];

    $run_sql2 = "SELECT *,COUNT(*) FROM c_map where curricul_sub ='$sub' AND class = 'E-Book' AND prog_id = '$program_id';";
    $run_query2 = mysqli_query($con, $run_sql2);
    $result2 = mysqli_fetch_assoc($run_query2);
    

    $run_sql3 = "SELECT *,COUNT(*) FROM c_map where curricul_sub ='$sub' AND class = 'General Reference' AND prog_id = '$program_id';";
    $run_query3 = mysqli_query($con, $run_sql3);
    $result3 = mysqli_fetch_assoc($run_query3);
    
    if(in_array($sub, $isExist) || in_array($sub, $isExistFil) || in_array($sub, $isExistEb) || in_array($sub, $isExistGr)){
        continue;
    }else {
        $isExist[$count] = $result['curricul_sub'];
        $dataPointsy2[$count]['label'] = $result['curricul_sub'];
        $dataPointsy2[$count]['y'] = $total;

        $isExistFil[$count] = $result1['curricul_sub'];
        $dataPointsy1[$count]['label'] = $result1['curricul_sub'];
        $dataPointsy1[$count]['y'] = $total1;

        $isExistEb[$count] = $result2['curricul_sub'];
        $dataPointsy3[$count]['label'] = $result2['curricul_sub'];
        $dataPointsy3[$count]['y'] = $result2['COUNT(*)'];

        $isExistGr[$count] = $result3['curricul_sub'];
        $dataPointsy4[$count]['label'] = $result3['curricul_sub'];
        $dataPointsy4[$count]['y'] = $result3['COUNT(*)'];
        
        $count++;
    }
}

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="style.css">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <title>Reports</title>
    <style>
        body {
            background-color: #e9e2c7;
        }

        .hover {
            background-color: #9c1d24;
            color: white;
        }

        a {
            text-decoration: none;
            color: white
        }

        a:hover {
            background-color: white !important;
            color: black
        }

        .graph {
            height: 370px;
            width: 100%;
        }
    </style>
    
</head>
<script>window.onload = function () {
    var chart1 = new CanvasJS.Chart("chartContainer1", {
        animationEnabled: true,
        exportEnabled: true,
        theme: "light1",
        title: {
            text: "Circulation"
        },
        axisY: {
            includeZero: false
        },
        data: [{
            type: "column",
            name: "Circulation",
            indexLabelFontColor: "#5A5757",
            indexLabelPlacement: "outside",
            dataPoints: <?php echo json_encode($dataPointsy2, JSON_NUMERIC_CHECK); ?>
        }]
    });
    chart1.render();

    var chart2 = new CanvasJS.Chart("chartContainer2", {
        animationEnabled: true,
        exportEnabled: true,
        theme: "light1",
        title: {
            text: "Filipiniana"
        },
        axisY: {
            includeZero: false
        },
        data: [{
            type: "column",
            name: "Filipiniana",
            indexLabelFontColor: "#5A5757",
            indexLabelPlacement: "outside",
            dataPoints: <?php echo json_encode($dataPointsy1, JSON_NUMERIC_CHECK); ?>
        }]
    });
    chart2.render();

    var chart3 = new CanvasJS.Chart("chartContainer3", {
        animationEnabled: true,
        exportEnabled: true,
        theme: "light1",
        title: {
            text: "E-Book"
        },
        axisY: {
            includeZero: false
        },
        data: [{
            type: "column",
            name: "E-Book",
            indexLabelFontColor: "#5A5757",
            indexLabelPlacement: "outside",
            dataPoints: <?php echo json_encode($dataPointsy3, JSON_NUMERIC_CHECK); ?>
        }]
    });
    chart3.render();

    var chart4 = new CanvasJS.Chart("chartContainer4", {
        animationEnabled: true,
        exportEnabled: true,
        theme: "light1",
        title: {
            text: "General Reference"
        },
        axisY: {
            includeZero: false
        },
        data: [{
            type: "column",
            name: "General Reference",
            indexLabelFontColor: "#5A5757",
            indexLabelPlacement: "outside",
            dataPoints: <?php echo json_encode($dataPointsy4, JSON_NUMERIC_CHECK); ?>
        }]
    });
    chart4.render();
}

</script>
<nav>
	<input id="nav-toggle" type="checkbox">
	<ul class="links">
		<a href="reports.php">Back</a>
	</ul>
	<label for="nav-toggle" class="icon-burger">
		<div class="line"></div>
		<div class="line"></div>
		<div class="line"></div>
	</label>
</nav>
<body>
    <div class="container mt-5">
        <br>
        <div class="card">
            <div class="card-header">
                <h4>Analytics Visualization</h4>
            </div>
            <div class="card-body">
                <h1 class='text-center'><?php echo $program['prog_name']?></h1>
                <div id="chartContainer1" style="height: 300px; width: 100%;"></div>
                <br>
                <div id="chartContainer2" style="height: 300px; width: 100%;"></div>
                <br>
                <div id="chartContainer3" style="height: 300px; width: 100%;"></div>
                <br>
                <div id="chartContainer4" style="height: 300px; width: 100%;"></div>
            </div>
        </div>

    </div>
    <script src="https://cdn.canvasjs.com/canvasjs.min.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>