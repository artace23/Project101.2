<?php


    require_once 'classes/PHPExcel/IOFactory.php';

    if(isset($_FILES['excel_file']) && !empty($_FILES['excel_file']['tmp_name'])) {
        $fileInfo = pathinfo($_FILES['excel_file']['name']);
        $fileExtension = strtolower($fileInfo['extension']);
    
        if ($fileExtension === 'xlsx') {
            // It's a valid .xlsx file
            $excelOject = PHPExcel_IOFactory::load($_FILES['excel_file']['tmp_name']);
    
            $getSheetRefFil = $excelOject->getSheetByName("Ref. Fil.");
            $getSheetRefCir = $excelOject->getSheetByName("Ref. Cir.");
            $getSheetCir = $excelOject->getSheetByName("Cir.");
            $getSheetFil = $excelOject->getSheetByName("Fil.");
    
            $lastRowRefFil = $getSheetRefFil->getHighestRow();
            $lastRowRefCir = $getSheetRefCir->getHighestRow();
            $lastRowCir = $getSheetCir->getHighestRow();
            $lastRowFil = $getSheetFil->getHighestRow();
    
            // Rest of your code
        } else {
            echo "<script> alert('Please upload a valid .xlsx file.') </script>";
            echo '<script>window.location.href = "index.php";</script>';
            exit;
        }
    }

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="admin/style.css">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
	<title>General Collection</title>
    <style>
        body {
            background-color: #e9e2c7;
        }

        .hover {
            background-color: #9c1d24;
            color: white;
        }

        a {
            text-decoration: none;
            color: white
        }

        a:hover {
            background-color: white !important;
            color: black
        }

        .graph {
            height: 370px;
            width: 100%;
        }
    </style>
</head>
<body>
<nav>
	<input id="nav-toggle" type="checkbox">
	<ul class="links">
		<a href="index.php">Back</a>
	</ul>
	<label for="nav-toggle" class="icon-burger">
		<div class="line"></div>
		<div class="line"></div>
		<div class="line"></div>
	</label>
</nav>
    <div class="container mt-5">
        <br>
        <div class="card">
            <div class="card-header">
                <h4>Reports</h4>
            </div>
            <div class="card-body">
                <br>
                <div class="card text-center">
                    <a href="" data-bs-toggle="modal" data-bs-target="#summ_copyrights">
                        <div class="hover card-header m-3">
                        <br>
                            <h4>Summary of Copyrights - Titles</h4>
                        <br>
                        </div>
                    </a>
                </div>
                <br>
                <div class="card text-center">
                    <a href="" data-bs-toggle="modal" data-bs-target="#summ_materials">
                        <div class="hover card-header m-3">
                        <br>
                            <h4>Summary of Learnig Resource Materials - Subject</h4>
                        <br>
                        </div>
                    </a>
                </div>
                <br>
                <div class="card text-center">
                    <a href="" data-bs-toggle="modal" data-bs-target="#summ_volume">
                        <div class="hover card-header m-3">
                        <br>
                            <h4>Collection Area - DDC Subject - Volume</h4>
                        <br>
                        </div>
                    </a>
                </div>
                <br>
                <div class="card text-center">
                    <a href="" data-bs-toggle="modal" data-bs-target="#summ_collect">
                        <div class="hover card-header m-3">
                        <br>
                            <h4>Summary of Collection</h4>
                        <br>
                        </div>
                    </a>
                </div>
                <br>
            </div>
        </div>

        <!-- Copyrights modal -->
        <div class="modal fade" id="summ_copyrights" tabindex="-1" aria-labelledby="summ_copyrightsLabel" aria-hidden="true">
                <div class="modal-dialog modal-xl modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Summary of Copyrights - Title</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <table class="table table-bordered border-dark">
                            <thead class="text-center">
                                <tr>
                                    <th>YEAR</th>
                                    <th>AGE</th>
                                    <th>FIL</th>
                                    <th>CIR</th>
                                    <th>Gen.Ref Cir</th>
                                    <th>Gen.Ref Fil</th>
                                    <th>TOTAL</th>
                                    <th>%</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $columnIndexRefFil = null;
                                    $columnIndexRefCir = null;
                                    $columnIndexCir = null;
                                    $columnIndexFil = null;
                                    $columnIndexRefFil1 = null;
                                    $columnIndexRefCir1 = null;
                                    $columnIndexCir1 = null;
                                    $columnIndexFil1 = null;
                                    $title2018 = array('1'=>0,'2'=>0,'3'=>0,'4'=>0);
                                    $title2013 = array('1'=>0,'2'=>0,'3'=>0,'4'=>0); 
                                    $title2008 = array('1'=>0,'2'=>0,'3'=>0,'4'=>0);
                                    $title2003 = array('1'=>0,'2'=>0,'3'=>0,'4'=>0);
                                    $title2002 = array('1'=>0,'2'=>0,'3'=>0,'4'=>0);
                                    $titlenone = array('1'=>0,'2'=>0,'3'=>0,'4'=>0);

                                    foreach ($getSheetCir->getRowIterator(1) as $row) {
                                        foreach ($row->getCellIterator() as $cell) {
                                            if ($cell->getValue() == "YEAR") {
                                                $columnIndexCir = $cell->getColumn();
                                            }
                                        }
                                    }
    
                                    foreach ($getSheetFil->getRowIterator(1) as $row) {
                                        foreach ($row->getCellIterator() as $cell) {
                                            if ($cell->getValue() == "YEAR") {
                                                $columnIndexFil = $cell->getColumn();
                                            }
                                        }
                                    }
    
                                    foreach ($getSheetRefCir->getRowIterator(1) as $row) {
                                        foreach ($row->getCellIterator() as $cell) {
                                            if ($cell->getValue() == "YEAR") {
                                                $columnIndexRefCir = $cell->getColumn();
                                            }
                                        }
                                    }
    
                                    foreach ($getSheetRefFil->getRowIterator(1) as $row) {
                                        foreach ($row->getCellIterator() as $cell) {
                                            if ($cell->getValue() == "YEAR") {
                                                $columnIndexRefFil = $cell->getColumn();
                                            }
                                        }
                                    }
                                    
                                    if ($columnIndexFil) {
                                        for ($row = 2; $row <= $lastRowFil; $row++) {
                                            $cell = $getSheetFil->getCell($columnIndexFil . $row);
                                            $cellValue = $cell->getValue(); 
                                    
                                            if ($cellValue >= 2018 && $cellValue <= 2022) {
                                                $title2018['1']++;
                                            }
                                            elseif ($cellValue >= 2013 && $cellValue <= 2017) {
                                                $title2013['1']++;
                                            }
                                            elseif ($cellValue >= 2008 && $cellValue <= 2012) {
                                                $title2008['1']++;
                                            }
                                            elseif ($cellValue >= 2003 && $cellValue <= 2007) {
                                                $title2003['1']++;
                                            }
                                            elseif ($cellValue <= 2002) {
                                                $title2002['1']++;
                                            }
                                            else {
                                                $titlenone['1']++;
                                            }
                                        }
                                        
                                    }
    
                                    if ($columnIndexCir) {
                                        for ($row = 2; $row <= $lastRowCir; $row++) {
                                            $cell = $getSheetCir->getCell($columnIndexCir . $row);
                                            $cellValue = $cell->getValue();
                                    
                                            if ($cellValue >= 2018 && $cellValue <= 2022) {
                                                $title2018['2']++;
                                            }
                                            elseif ($cellValue >= 2013 && $cellValue <= 2017) {
                                                $title2013['2']++;
                                            }
                                            elseif ($cellValue >= 2008 && $cellValue <= 2012) {
                                                $title2008['2']++;
                                            }
                                            elseif ($cellValue >= 2003 && $cellValue <= 2007) {
                                                $title2003['2']++;
                                            }
                                            elseif ($cellValue <= 2002) {
                                                $title2002['2']++;
                                            }
                                            else {
                                                $titlenone['2']++;
                                            }
                                        }
                                    }
    
                                    if ($columnIndexRefFil) {
                                        for ($row = 2; $row <= $lastRowRefFil; $row++) {
                                            $cell = $getSheetRefFil->getCell($columnIndexRefFil . $row);
                                            $cellValue = $cell->getValue(); 
                                    
                                            if ($cellValue >= 2018 && $cellValue <= 2022) {
                                                $title2018['3']++;
                                            }
                                            elseif ($cellValue >= 2013 && $cellValue <= 2017) {
                                                $title2013['3']++;
                                            }
                                            elseif ($cellValue >= 2008 && $cellValue <= 2012) {
                                                $title2008['3']++;
                                            }
                                            elseif ($cellValue >= 2003 && $cellValue <= 2007) {
                                                $title2003['3']++;
                                            }
                                            elseif ($cellValue <= 2002) {
                                                $title2002['3']++;
                                            }
                                            else {
                                                $titlenone['3']++;
                                            }
                                        }
                                    }
                                    
                                    if ($columnIndexRefCir) {
                                        for ($row = 2; $row <= $lastRowRefCir; $row++) {
                                            $cell = $getSheetRefCir->getCell($columnIndexRefCir . $row);
                                            $cellValue = $cell->getValue(); 
                                    
                                            if ($cellValue >= 2018 && $cellValue <= 2022) {
                                                $title2018['4']++;
                                            }
                                            elseif ($cellValue >= 2013 && $cellValue <= 2017) {
                                                $title2013['4']++;
                                            }
                                            elseif ($cellValue >= 2008 && $cellValue <= 2012) {
                                                $title2008['4']++;
                                            }
                                            elseif ($cellValue >= 2003 && $cellValue <= 2007) {
                                                $title2003['4']++;
                                            }
                                            elseif ($cellValue <= 2002) {
                                                $title2002['4']++;
                                            }
                                            else {
                                                $titlenone['4']++;
                                            }
                                        }
                                    }

                                    $total2018 = $title2018['1'] + $title2018['2'] + $title2018['3'] + $title2018['4'];
                                    $total2013 = $title2013['1'] + $title2013['2'] + $title2013['3'] + $title2013['4'];
                                    $total2008 = $title2008['1'] + $title2008['2'] + $title2008['3'] + $title2008['4'];
                                    $total2003 = $title2003['1'] + $title2003['2'] + $title2003['3'] + $title2003['4'];
                                    $total2002 = $title2002['1'] + $title2002['2'] + $title2002['3'] + $title2002['4'];
                                    $totalnone = $titlenone['1'] + $titlenone['2'] + $titlenone['3'] + $titlenone['4'];

                                    $totalFil = $title2018['1'] + $title2013['1'] + $title2008['1'] + $title2003['1'] + $title2002['1'] + $titlenone['1'];
                                    $totalCir = $title2018['2'] + $title2013['2'] + $title2008['2'] + $title2003['2'] + $title2002['2'] + $titlenone['2'];
                                    $totalRefFil = $title2018['3'] + $title2013['3'] + $title2008['3'] + $title2003['3'] + $title2002['3'] + $titlenone['3'];
                                    $totalRefCir = $title2018['4'] + $title2013['4'] + $title2008['4'] + $title2003['4'] + $title2002['4'] + $titlenone['4'];

                                    $totalAll = $total2018 + $total2013 + $total2008 + $total2003 + $total2002 + $totalnone;

                                    $year = date("Y");
                                ?>
                                <tr>
                                    <td>2018-2022</td>
                                    <td><?php echo $year-2018?></td>
                                    <td><?php echo $title2018['1']?></td>
                                    <td><?php echo $title2018['2']?></td>
                                    <td><?php echo $title2018['3']?></td>
                                    <td><?php echo $title2018['4']?></td>
                                    <td><?php echo $total2018?></td>
                                    <td><?php echo ($total2018 === 0 ? 0 : round(($total2018/$totalAll)*100, 2))?>%</td>
                                </tr>

                                <tr>
                                    <td>2013-2017</td>
                                    <td><?php echo $year-2013?></td>
                                    <td><?php echo $title2013['1']?></td>
                                    <td><?php echo $title2013['2']?></td>
                                    <td><?php echo $title2013['3']?></td>
                                    <td><?php echo $title2013['4']?></td>
                                    <td><?php echo $total2013?></td>
                                    <td><?php echo ($total2013 === 0 ? 0 : round(($total2013/$totalAll)*100, 2))?>%</td>
                                </tr>

                                <tr>
                                    <td>2008-2012</td>
                                    <td><?php echo $year-2008?></td>
                                    <td><?php echo $title2008['1']?></td>
                                    <td><?php echo $title2008['2']?></td>
                                    <td><?php echo $title2008['3']?></td>
                                    <td><?php echo $title2008['4']?></td>
                                    <td><?php echo $total2008?></td>
                                    <td><?php echo ($total2008 === 0 ? 0 : round(($total2008/$totalAll)*100, 2))?>%</td>
                                </tr>

                                <tr>
                                    <td>2003-2007</td>
                                    <td><?php echo $year-2003?></td>
                                    <td><?php echo $title2003['1']?></td>
                                    <td><?php echo $title2003['2']?></td>
                                    <td><?php echo $title2003['3']?></td>
                                    <td><?php echo $title2003['4']?></td>
                                    <td><?php echo $total2003?></td>
                                    <td><?php echo ($total2003 === 0 ? 0 : round(($total2003/$totalAll)*100, 2))?>%</td>
                                </tr>

                                <tr>
                                    <td>2002-Below</td>
                                    <td><?php echo $year-2002?></td>
                                    <td><?php echo $title2002['1']?></td>
                                    <td><?php echo $title2002['2']?></td>
                                    <td><?php echo $title2002['3']?></td>
                                    <td><?php echo $title2002['4']?></td>
                                    <td><?php echo $total2002?></td>
                                    <td><?php echo ($total2002 === 0 ? 0 : round(($total2002/$totalAll)*100, 2))?>%</td>
                                </tr>

                                <tr>
                                    <td>w/o copyright</td>
                                    <td></td>
                                    <td><?php echo $titlenone['1']?></td>
                                    <td><?php echo $titlenone['2']?></td>
                                    <td><?php echo $titlenone['3']?></td>
                                    <td><?php echo $titlenone['4']?></td>
                                    <td><?php echo $totalnone?></td>
                                    <td><?php echo ($totalnone === 0 ? 0 : round(($totalnone/$totalAll)*100, 2))?>%</td>
                                </tr>

                                <tr>
                                    <td>Total</td>
                                    <td></td>
                                    <td><?php echo $totalFil?></td>
                                    <td><?php echo $totalCir?></td>
                                    <td><?php echo $totalRefCir?></td>
                                    <td><?php echo $totalRefFil?></td>
                                    <td><?php echo $totalAll?></td>
                                    <td>100%</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="modal-footer">
                    </div>
                </div>
                </div>
            </div>
        <!--  -->

        <!-- volume modal -->
        <div class="modal fade" id="summ_volume" tabindex="-1" aria-labelledby="summ_volumeLabel" aria-hidden="true">
                <div class="modal-dialog modal-xl modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Collection Area - DDC Subject - Volume</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <table class="table table-bordered border-dark">
                            <thead class="text-center">
                                <tr>
                                    <th>Class#</th>
                                    <th>Class</th>
                                    <th>Cir</th>
                                    <th>Fil</th>
                                    <th>Gen.Ref Cir</th>
                                    <th>Gen.Ref Fil</th>
                                    <th>Total</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php
                                $columnIndexRefFil = null;
                                $columnIndexRefCir = null;
                                $columnIndexCir = null;
                                $columnIndexFil = null;
                                $columnIndexRefFil1 = null;
                                $columnIndexRefCir1 = null;
                                $columnIndexCir1 = null;
                                $columnIndexFil1 = null;
                                $class1 = array('1'=>0.0, '2'=>0.0, '3'=>0.0, '4'=>0.0, '5'=>0.0, '6'=>0.0, '7'=>0.0, '8'=>0.0);
                                $class2 = array('1'=>0.0, '2'=>0.0, '3'=>0.0, '4'=>0.0, '5'=>0.0, '6'=>0.0, '7'=>0.0, '8'=>0.0);
                                $class3 = array('1'=>0.0, '2'=>0.0, '3'=>0.0, '4'=>0.0, '5'=>0.0, '6'=>0.0, '7'=>0.0, '8'=>0.0);
                                $class4 = array('1'=>0.0, '2'=>0.0, '3'=>0.0, '4'=>0.0, '5'=>0.0, '6'=>0.0, '7'=>0.0, '8'=>0.0);
                                $class5 = array('1'=>0.0, '2'=>0.0, '3'=>0.0, '4'=>0.0, '5'=>0.0, '6'=>0.0, '7'=>0.0, '8'=>0.0);
                                $class6 = array('1'=>0.0, '2'=>0.0, '3'=>0.0, '4'=>0.0, '5'=>0.0, '6'=>0.0, '7'=>0.0, '8'=>0.0);
                                $class7 = array('1'=>0.0, '2'=>0.0, '3'=>0.0, '4'=>0.0, '5'=>0.0, '6'=>0.0, '7'=>0.0, '8'=>0.0);
                                $class8 = array('1'=>0.0, '2'=>0.0, '3'=>0.0, '4'=>0.0, '5'=>0.0, '6'=>0.0, '7'=>0.0, '8'=>0.0);
                                $class9 = array('1'=>0.0, '2'=>0.0, '3'=>0.0, '4'=>0.0, '5'=>0.0, '6'=>0.0, '7'=>0.0, '8'=>0.0);
                                $class10 = array('1'=>0.0, '2'=>0.0, '3'=>0.0, '4'=>0.0, '5'=>0.0, '6'=>0.0, '7'=>0.0, '8'=>0.0);

                                
                                foreach ($getSheetCir->getRowIterator(1) as $row) {
                                    foreach ($row->getCellIterator() as $cell) {
                                        if ($cell->getValue() == "CLASS NO.") {
                                            $columnIndexCir = $cell->getColumn();
                                        }elseif ($cell->getValue() == "VOLUMES") {
                                            $columnIndexCir1 = $cell->getColumn();
                                        }
                                    }
                                }

                                foreach ($getSheetFil->getRowIterator(1) as $row) {
                                    foreach ($row->getCellIterator() as $cell) {
                                        if ($cell->getValue() == "CLASS NO.") {
                                            $columnIndexFil = $cell->getColumn();
                                        }elseif ($cell->getValue() == "VOLUMES") {
                                            $columnIndexFil1 = $cell->getColumn();
                                        }
                                    }
                                }

                                foreach ($getSheetRefCir->getRowIterator(1) as $row) {
                                    foreach ($row->getCellIterator() as $cell) {
                                        if ($cell->getValue() == "CLASS NO.") {
                                            $columnIndexRefCir = $cell->getColumn();
                                        }elseif ($cell->getValue() == "VOLUMES") {
                                            $columnIndexRefCir1 = $cell->getColumn();
                                        }
                                    }
                                }

                                foreach ($getSheetRefFil->getRowIterator(1) as $row) {
                                    foreach ($row->getCellIterator() as $cell) {
                                        if ($cell->getValue() == "CLASS NO.") {
                                            $columnIndexRefFil = $cell->getColumn();
                                        }elseif ($cell->getValue() == "VOLUMES") {
                                            $columnIndexRefFil1 = $cell->getColumn();
                                        }
                                    }
                                }
                                
                                

                                if ($columnIndexFil) {
                                    for ($row = 2; $row <= $lastRowFil; $row++) {
                                        $cell = $getSheetFil->getCell($columnIndexFil . $row);
                                        $cell1 = $getSheetFil->getCell($columnIndexFil1 . $row);
                                        $cellValue = $cell->getValue(); // Get the cell value
                                        $cellVolume = $cell1->getValue();
                                
                                        if ((float)$cellValue >= 0.0 && (float)$cellValue <= 99.0) {
                                            $class1['1'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 100.0 && (float)$cellValue <= 199.0) {
                                            $class2['1'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 200.0 && (float)$cellValue <= 299.0) {
                                            $class3['1'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 300.0 && (float)$cellValue <= 399.0) {
                                            $class4['1'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 400.0 && (float)$cellValue <= 499.0) {
                                            $class5['1'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 500.0 && (float)$cellValue <= 599.0) {
                                            $class6['1'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 600.0 && (float)$cellValue <= 699.0) {
                                            $class7['1'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 700.0 && (float)$cellValue <= 799.0) {
                                            $class8['1'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 800.0 && (float)$cellValue <= 899.0) {
                                            $class9['1'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 900.0 && (float)$cellValue <= 999.0) {
                                            $class10['1'] += (int)$cellVolume;
                                        }
                                    }
                                    
                                }

                                if ($columnIndexCir) {
                                    for ($row = 2; $row <= $lastRowCir; $row++) {
                                        $cell = $getSheetCir->getCell($columnIndexCir . $row);
                                        $cell1 = $getSheetCir->getCell($columnIndexCir1 . $row);
                                        $cellValue = $cell->getValue(); // Get the cell value
                                        $cellVolume = $cell1->getValue();
                                
                                        if ((float)$cellValue >= 0.0 && (float)$cellValue <= 99.0) {
                                            $class1['2'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 100.0 && (float)$cellValue <= 199.0) {
                                            $class2['2'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 200.0 && (float)$cellValue <= 299.0) {
                                            $class3['2'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 300.0 && (float)$cellValue <= 399.0) {
                                            $class4['2'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 400.0 && (float)$cellValue <= 499.0) {
                                            $class5['2'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 500.0 && (float)$cellValue <= 599.0) {
                                            $class6['2'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 600.0 && (float)$cellValue <= 699.0) {
                                            $class7['2'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 700.0 && (float)$cellValue <= 799.0) {
                                            $class8['2'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 800.0 && (float)$cellValue <= 899.0) {
                                            $class9['2'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 900.0 && (float)$cellValue <= 999.0) {
                                            $class10['2'] += (int)$cellVolume;
                                        }
                                    }
                                }

                                if ($columnIndexRefFil) {
                                    for ($row = 2; $row <= $lastRowRefFil; $row++) {
                                        $cell = $getSheetRefFil->getCell($columnIndexRefFil . $row);
                                        $cell1 = $getSheetRefFil->getCell($columnIndexRefFil1 . $row);
                                        $cellValue = $cell->getValue(); // Get the cell value
                                        $cellVolume = $cell1->getValue();
                                
                                        if ((float)$cellValue >= 0.0 && (float)$cellValue <= 99.0) {
                                            $class1['3'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 100.0 && (float)$cellValue <= 199.0) {
                                            $class2['3'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 200.0 && (float)$cellValue <= 299.0) {
                                            $class3['3'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 300.0 && (float)$cellValue <= 399.0) {
                                            $class4['3'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 400.0 && (float)$cellValue <= 499.0) {
                                            $class5['3'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 500.0 && (float)$cellValue <= 599.0) {
                                            $class6['3'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 600.0 && (float)$cellValue <= 699.0) {
                                            $class7['3'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 700.0 && (float)$cellValue <= 799.0) {
                                            $class8['3'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 800.0 && (float)$cellValue <= 899.0) {
                                            $class9['3'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 900.0 && (float)$cellValue <= 999.0) {
                                            $class10['3'] += (int)$cellVolume;
                                        }
                                    }
                                }
                                
                                if ($columnIndexRefCir) {
                                    for ($row = 2; $row <= $lastRowRefCir; $row++) {
                                        $cell = $getSheetRefCir->getCell($columnIndexRefCir . $row);
                                        $cell1 = $getSheetRefCir->getCell($columnIndexRefCir1 . $row);
                                        $cellValue = $cell->getValue(); // Get the cell value
                                        $cellVolume = $cell1->getValue();
                                
                                        if ((float)$cellValue >= 0.0 && (float)$cellValue <= 99.0) {
                                            $class1['4'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 100.0 && (float)$cellValue <= 199.0) {
                                            $class2['4'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 200.0 && (float)$cellValue <= 299.0) {
                                            $class3['4'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 300.0 && (float)$cellValue <= 399.0) {
                                            $class4['4'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 400.0 && (float)$cellValue <= 499.0) {
                                            $class5['4'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 500.0 && (float)$cellValue <= 599.0) {
                                            $class6['4'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 600.0 && (float)$cellValue <= 699.0) {
                                            $class7['4'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 700.0 && (float)$cellValue <= 799.0) {
                                            $class8['4'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 800.0 && (float)$cellValue <= 899.0) {
                                            $class9['4'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 900.0 && (float)$cellValue <= 999.0) {
                                            $class10['4'] += (int)$cellVolume;
                                        }
                                    }
                                }
                                $totalClass1 = $class1['1'] + $class1['2'] + $class1['3'] + $class1['4'];

                                $totalClass2 = $class2['1'] + $class2['2'] + $class2['3'] + $class2['4'];
                                
                                $totalClass3 = $class3['1'] + $class3['2'] + $class3['3'] + $class3['4'];
                                
                                $totalClass4 = $class4['1'] + $class4['2'] + $class4['3'] + $class4['4'];
                                
                                $totalClass5 = $class5['1'] + $class5['2'] + $class5['3'] + $class5['4'];
                                
                                $totalClass6 = $class6['1'] + $class6['2'] + $class6['3'] + $class6['4'];
                                
                                $totalClass7 = $class7['1'] + $class7['2'] + $class7['3'] + $class7['4'];
                                
                                $totalClass8 = $class8['1'] + $class8['2'] + $class8['3'] + $class8['4'];
                                
                                $totalClass9 = $class9['1'] + $class9['2'] + $class9['3'] + $class9['4'];
                                
                                $totalClass10 = $class10['1'] + $class10['2'] + $class10['3'] + $class10['4'];

                                $totalAll = $totalClass1 + $totalClass2 + $totalClass3 + $totalClass4 + $totalClass5 + $totalClass6 + $totalClass7 + $totalClass8 + $totalClass9 + $totalClass10;

                                
                            ?>
                                tr>
                                    <td>000-099</td>
                                    <td>GEN</td>
                                    <td><?php echo ($class1['1'])?></td>
                                    <td><?php echo ($class1['2'])?></td>
                                    <td><?php echo ($class1['3'])?></td>
                                    <td><?php echo ($class1['4'])?></td>
                                    <td><?php echo $totalClass1?></td>
                                </tr>
                                <tr>
                                    <td>100-199</td>
                                    <td>PYS/PHILO</td>
                                    <td><?php echo ($class2['1'])?></td>
                                    <td><?php echo ($class2['2'])?></td>
                                    <td><?php echo ($class2['3'])?></td>
                                    <td><?php echo ($class2['4'])?></td>
                                    <td><?php echo $totalClass2?></td>
                                </tr>
                                <tr>
                                    <td>200-299</td>
                                    <td>RELIGION</td>
                                    <td><?php echo ($class3['1'])?></td>
                                    <td><?php echo ($class3['2'])?></td>
                                    <td><?php echo ($class3['3'])?></td>
                                    <td><?php echo ($class3['4'])?></td>
                                    <td><?php echo $totalClass3?></td>
                                </tr>
                                <tr>
                                    <td>300-399</td>
                                    <td>SOC SCI</td>
                                    <td><?php echo ($class4['1'])?></td>
                                    <td><?php echo ($class4['2'])?></td>
                                    <td><?php echo ($class4['3'])?></td>
                                    <td><?php echo ($class4['4'])?></td>
                                    <td><?php echo $totalClass4?></td>
                                </tr>
                                <tr>
                                    <td>400-499</td>
                                    <td>LANG</td>
                                    <td><?php echo ($class5['1'])?></td>
                                    <td><?php echo ($class5['2'])?></td>
                                    <td><?php echo ($class5['3'])?></td>
                                    <td><?php echo ($class5['4'])?></td>
                                    <td><?php echo $totalClass5?></td>
                                </tr>
                                <tr>
                                    <td>500-599</td>
                                    <td>PURE SCI</td>
                                    <td><?php echo ($class6['1'])?></td>
                                    <td><?php echo ($class6['2'])?></td>
                                    <td><?php echo ($class6['3'])?></td>
                                    <td><?php echo ($class6['4'])?></td>
                                    <td><?php echo $totalClass6?></td>
                                </tr>
                                <tr>
                                    <td>600-699</td>
                                    <td>APP SCI</td>
                                    <td><?php echo ($class7['1'])?></td>
                                    <td><?php echo ($class7['2'])?></td>
                                    <td><?php echo ($class7['3'])?></td>
                                    <td><?php echo ($class7['4'])?></td>
                                    <td><?php echo $totalClass7?></td>
                                </tr>
                                <tr>
                                    <td>700-799</td>
                                    <td>FA/RECRE</td>
                                    <td><?php echo ($class8['1'])?></td>
                                    <td><?php echo ($class8['2'])?></td>
                                    <td><?php echo ($class8['3'])?></td>
                                    <td><?php echo ($class8['4'])?></td>
                                    <td><?php echo $totalClass8?></td>
                                </tr>
                                <tr>
                                    <td>800-899</td>
                                    <td>LIT/RHETO</td>
                                    <td><?php echo ($class9['1'])?></td>
                                    <td><?php echo ($class9['2'])?></td>
                                    <td><?php echo ($class9['3'])?></td>
                                    <td><?php echo ($class9['4'])?></td>
                                    <td><?php echo $totalClass9?></td>
                                </tr>
                                <tr>
                                    <td>900-999</td>
                                    <td>HIST/GEO</td>
                                    <td><?php echo ($class10['1'])?></td>
                                    <td><?php echo ($class10['2'])?></td>
                                    <td><?php echo ($class10['3'])?></td>
                                    <td><?php echo ($class10['4'])?></td>
                                    <td><?php echo $totalClass10?></td>
                                </tr>
                                <tr>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td>Total</td>
                                    <td><?php echo $totalAll?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="modal-footer">
                    </div>
                </div>
                </div>
            </div>
        <!--  -->

        <!-- materials modal -->
        <div class="modal fade" id="summ_materials" tabindex="-1" aria-labelledby="summ_materialsLabel" aria-hidden="true">
                <div class="modal-dialog modal-xl modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Summary of Learnig Resource Materials - Subject</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <table class="table table-bordered border-dark">
                            <thead class="text-center">
                                <tr>
                                    <th colspan="2">Course</th>
                                    <th colspan="8">Books</th>
                                    <th>Total</th>
                                    <th> % </th>
                                </tr>
                                <tr>
                                    <th>Class No.</th>
                                    <th>Class</th>
                                    <th colspan="2">Fil</th>
                                    <th colspan="2">Cir</th>
                                    <th colspan="2">Gen.Ref Fil</th>
                                    <th colspan="2">Gen.Ref Cir</th>
                                    <th></th>
                                    <th></th>
                                </tr>
                                <tr>
                                    <th></th>
                                    <th></th>
                                    <th>Title</th>
                                    <th>Volume</th>
                                    <th>Title</th>
                                    <th>Volume</th>
                                    <th>Title</th>
                                    <th>Volume</th>
                                    <th>Title</th>
                                    <th>Volume</th>
                                    <th></th>
                                    <th></th>
                                </tr>
                            </thead>

                            <?php
                                $columnIndexRefFil = null;
                                $columnIndexRefCir = null;
                                $columnIndexCir = null;
                                $columnIndexFil = null;
                                $columnIndexRefFil1 = null;
                                $columnIndexRefCir1 = null;
                                $columnIndexCir1 = null;
                                $columnIndexFil1 = null;
                                $class1 = array('1'=>0.0, '2'=>0.0, '3'=>0.0, '4'=>0.0, '5'=>0.0, '6'=>0.0, '7'=>0.0, '8'=>0.0);
                                $class2 = array('1'=>0.0, '2'=>0.0, '3'=>0.0, '4'=>0.0, '5'=>0.0, '6'=>0.0, '7'=>0.0, '8'=>0.0);
                                $class3 = array('1'=>0.0, '2'=>0.0, '3'=>0.0, '4'=>0.0, '5'=>0.0, '6'=>0.0, '7'=>0.0, '8'=>0.0);
                                $class4 = array('1'=>0.0, '2'=>0.0, '3'=>0.0, '4'=>0.0, '5'=>0.0, '6'=>0.0, '7'=>0.0, '8'=>0.0);
                                $class5 = array('1'=>0.0, '2'=>0.0, '3'=>0.0, '4'=>0.0, '5'=>0.0, '6'=>0.0, '7'=>0.0, '8'=>0.0);
                                $class6 = array('1'=>0.0, '2'=>0.0, '3'=>0.0, '4'=>0.0, '5'=>0.0, '6'=>0.0, '7'=>0.0, '8'=>0.0);
                                $class7 = array('1'=>0.0, '2'=>0.0, '3'=>0.0, '4'=>0.0, '5'=>0.0, '6'=>0.0, '7'=>0.0, '8'=>0.0);
                                $class8 = array('1'=>0.0, '2'=>0.0, '3'=>0.0, '4'=>0.0, '5'=>0.0, '6'=>0.0, '7'=>0.0, '8'=>0.0);
                                $class9 = array('1'=>0.0, '2'=>0.0, '3'=>0.0, '4'=>0.0, '5'=>0.0, '6'=>0.0, '7'=>0.0, '8'=>0.0);
                                $class10 = array('1'=>0.0, '2'=>0.0, '3'=>0.0, '4'=>0.0, '5'=>0.0, '6'=>0.0, '7'=>0.0, '8'=>0.0);

                                
                                foreach ($getSheetCir->getRowIterator(1) as $row) {
                                    foreach ($row->getCellIterator() as $cell) {
                                        if ($cell->getValue() == "CLASS NO.") {
                                            $columnIndexCir = $cell->getColumn();
                                        }elseif ($cell->getValue() == "VOLUMES") {
                                            $columnIndexCir1 = $cell->getColumn();
                                        }
                                    }
                                }

                                foreach ($getSheetFil->getRowIterator(1) as $row) {
                                    foreach ($row->getCellIterator() as $cell) {
                                        if ($cell->getValue() == "CLASS NO.") {
                                            $columnIndexFil = $cell->getColumn();
                                        }elseif ($cell->getValue() == "VOLUMES") {
                                            $columnIndexFil1 = $cell->getColumn();
                                        }
                                    }
                                }

                                foreach ($getSheetRefCir->getRowIterator(1) as $row) {
                                    foreach ($row->getCellIterator() as $cell) {
                                        if ($cell->getValue() == "CLASS NO.") {
                                            $columnIndexRefCir = $cell->getColumn();
                                        }elseif ($cell->getValue() == "VOLUMES") {
                                            $columnIndexRefCir1 = $cell->getColumn();
                                        }
                                    }
                                }

                                foreach ($getSheetRefFil->getRowIterator(1) as $row) {
                                    foreach ($row->getCellIterator() as $cell) {
                                        if ($cell->getValue() == "CLASS NO.") {
                                            $columnIndexRefFil = $cell->getColumn();
                                        }elseif ($cell->getValue() == "VOLUMES") {
                                            $columnIndexRefFil1 = $cell->getColumn();
                                        }
                                    }
                                }
                                
                                

                                if ($columnIndexFil) {
                                    for ($row = 2; $row <= $lastRowFil; $row++) {
                                        $cell = $getSheetFil->getCell($columnIndexFil . $row);
                                        $cell1 = $getSheetFil->getCell($columnIndexFil1 . $row);
                                        $cellValue = $cell->getValue(); // Get the cell value
                                        $cellVolume = $cell1->getValue();
                                
                                        if ((float)$cellValue >= 0.0 && (float)$cellValue <= 99.0) {
                                            $class1['1'] += 1;
                                            $class1['2'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 100.0 && (float)$cellValue <= 199.0) {
                                            $class2['1'] += 1;
                                            $class2['2'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 200.0 && (float)$cellValue <= 299.0) {
                                            $class3['1'] += 1;
                                            $class3['2'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 300.0 && (float)$cellValue <= 399.0) {
                                            $class4['1'] += 1;
                                            $class4['2'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 400.0 && (float)$cellValue <= 499.0) {
                                            $class5['1'] += 1;
                                            $class5['2'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 500.0 && (float)$cellValue <= 599.0) {
                                            $class6['1'] += 1;
                                            $class6['2'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 600.0 && (float)$cellValue <= 699.0) {
                                            $class7['1'] += 1;
                                            $class7['2'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 700.0 && (float)$cellValue <= 799.0) {
                                            $class8['1'] += 1;
                                            $class8['2'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 800.0 && (float)$cellValue <= 899.0) {
                                            $class9['1'] += 1;
                                            $class9['2'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 900.0 && (float)$cellValue <= 999.0) {
                                            $class10['1'] += 1;
                                            $class10['2'] += (int)$cellVolume;
                                        }
                                    }
                                    
                                }

                                if ($columnIndexCir) {
                                    for ($row = 2; $row <= $lastRowCir; $row++) {
                                        $cell = $getSheetCir->getCell($columnIndexCir . $row);
                                        $cell1 = $getSheetCir->getCell($columnIndexCir1 . $row);
                                        $cellValue = $cell->getValue(); // Get the cell value
                                        $cellVolume = $cell1->getValue();
                                
                                        if ((float)$cellValue >= 0.0 && (float)$cellValue <= 99.0) {
                                            $class1['3'] += 1;
                                            $class1['4'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 100.0 && (float)$cellValue <= 199.0) {
                                            $class2['3'] += 1;
                                            $class2['4'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 200.0 && (float)$cellValue <= 299.0) {
                                            $class3['3'] += 1;
                                            $class3['4'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 300.0 && (float)$cellValue <= 399.0) {
                                            $class4['3'] += 1;
                                            $class4['4'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 400.0 && (float)$cellValue <= 499.0) {
                                            $class5['3'] += 1;
                                            $class5['4'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 500.0 && (float)$cellValue <= 599.0) {
                                            $class6['3'] += 1;
                                            $class6['4'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 600.0 && (float)$cellValue <= 699.0) {
                                            $class7['3'] += 1;
                                            $class7['4'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 700.0 && (float)$cellValue <= 799.0) {
                                            $class8['3'] += 1;
                                            $class8['4'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 800.0 && (float)$cellValue <= 899.0) {
                                            $class9['3'] += 1;
                                            $class9['4'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 900.0 && (float)$cellValue <= 999.0) {
                                            $class10['3'] += 1;
                                            $class10['4'] += (int)$cellVolume;
                                        }
                                    }
                                }

                                if ($columnIndexRefFil) {
                                    for ($row = 2; $row <= $lastRowRefFil; $row++) {
                                        $cell = $getSheetRefFil->getCell($columnIndexRefFil . $row);
                                        $cell1 = $getSheetRefFil->getCell($columnIndexRefFil1 . $row);
                                        $cellValue = $cell->getValue(); // Get the cell value
                                        $cellVolume = $cell1->getValue();
                                
                                        if ((float)$cellValue >= 0.0 && (float)$cellValue <= 99.0) {
                                            $class1['5'] += 1;
                                            $class1['6'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 100.0 && (float)$cellValue <= 199.0) {
                                            $class2['5'] += 1;
                                            $class2['6'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 200.0 && (float)$cellValue <= 299.0) {
                                            $class3['5'] += 1;
                                            $class3['6'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 300.0 && (float)$cellValue <= 399.0) {
                                            $class4['5'] += 1;
                                            $class4['6'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 400.0 && (float)$cellValue <= 499.0) {
                                            $class5['5'] += 1;
                                            $class5['6'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 500.0 && (float)$cellValue <= 599.0) {
                                            $class6['5'] += 1;
                                            $class6['6'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 600.0 && (float)$cellValue <= 699.0) {
                                            $class7['5'] += 1;
                                            $class7['6'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 700.0 && (float)$cellValue <= 799.0) {
                                            $class8['5'] += 1;
                                            $class8['6'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 800.0 && (float)$cellValue <= 899.0) {
                                            $class9['5'] += 1;
                                            $class9['6'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 900.0 && (float)$cellValue <= 999.0) {
                                            $class10['5'] += 1;
                                            $class10['6'] += (int)$cellVolume;
                                        }
                                    }
                                }
                                
                                if ($columnIndexRefCir) {
                                    for ($row = 2; $row <= $lastRowRefCir; $row++) {
                                        $cell = $getSheetRefCir->getCell($columnIndexRefCir . $row);
                                        $cell1 = $getSheetRefCir->getCell($columnIndexRefCir1 . $row);
                                        $cellValue = $cell->getValue(); // Get the cell value
                                        $cellVolume = $cell1->getValue();
                                
                                        if ((float)$cellValue >= 0.0 && (float)$cellValue <= 99.0) {
                                            $class1['7'] += 1;
                                            $class1['8'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 100.0 && (float)$cellValue <= 199.0) {
                                            $class2['7'] += 1;
                                            $class2['8'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 200.0 && (float)$cellValue <= 299.0) {
                                            $class3['7'] += 1;
                                            $class3['8'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 300.0 && (float)$cellValue <= 399.0) {
                                            $class4['7'] += 1;
                                            $class4['8'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 400.0 && (float)$cellValue <= 499.0) {
                                            $class5['7'] += 1;
                                            $class5['8'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 500.0 && (float)$cellValue <= 599.0) {
                                            $class6['7'] += 1;
                                            $class6['8'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 600.0 && (float)$cellValue <= 699.0) {
                                            $class7['7'] += 1;
                                            $class7['8'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 700.0 && (float)$cellValue <= 799.0) {
                                            $class8['7'] += 1;
                                            $class8['8'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 800.0 && (float)$cellValue <= 899.0) {
                                            $class9['7'] += 1;
                                            $class9['8'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 900.0 && (float)$cellValue <= 999.0) {
                                            $class10['7'] += 1;
                                            $class10['8'] += (int)$cellVolume;
                                        }
                                    }
                                }

                                $total1 = $class1['1']+$class2['1']+$class3['1']+$class4['1']+$class5['1']+$class6['1']+$class7['1']+$class8['1']+$class9['1']+$class10['1'];

                                $total2 = $class1['2']+$class2['2']+$class3['2']+$class4['2']+$class5['2']+$class6['2']+$class7['2']+$class8['2']+$class9['2']+$class10['2'];

                                $total3 = $class1['3']+$class2['3']+$class3['3']+$class4['3']+$class5['3']+$class6['3']+$class7['3']+$class8['3']+$class9['3']+$class10['3'];

                                $total4 = $class1['4']+$class2['4']+$class3['4']+$class4['4']+$class5['4']+$class6['4']+$class7['4']+$class8['4']+$class9['4']+$class10['4'];

                                $total5 = $class1['5']+$class2['5']+$class3['5']+$class4['5']+$class5['5']+$class6['5']+$class7['5']+$class8['5']+$class9['5']+$class10['5'];

                                $total6 = $class1['6']+$class2['6']+$class3['6']+$class4['6']+$class5['6']+$class6['6']+$class7['6']+$class8['6']+$class9['6']+$class10['6'];

                                $total7 = $class1['7']+$class2['7']+$class3['7']+$class4['7']+$class5['7']+$class6['7']+$class7['7']+$class8['7']+$class9['7']+$class10['7'];

                                $total8 = $class1['8']+$class2['8']+$class3['8']+$class4['8']+$class5['8']+$class6['8']+$class7['8']+$class8['8']+$class9['8']+$class10['8'];
                                
                                $totalClass1 = $class1['1'] + $class1['2'] + $class1['3'] + $class1['4'] + $class1['5'] + $class1['6'] + $class1['7'] + $class1['8'];

                                $totalClass2 = $class2['1'] + $class2['2'] + $class2['3'] + $class2['4'] + $class2['5'] + $class2['6'] + $class2['7'] + $class2['8'];
                                
                                $totalClass3 = $class3['1'] + $class3['2'] + $class3['3'] + $class3['4'] + $class3['5'] + $class3['6'] + $class3['7'] + $class3['8'];
                                
                                $totalClass4 = $class4['1'] + $class4['2'] + $class4['3'] + $class4['4'] + $class4['5'] + $class4['6'] + $class4['7'] + $class4['8'];
                                
                                $totalClass5 = $class5['1'] + $class5['2'] + $class5['3'] + $class5['4'] + $class5['5'] + $class5['6'] + $class5['7'] + $class5['8'];
                                
                                $totalClass6 = $class6['1'] + $class6['2'] + $class6['3'] + $class6['4'] + $class6['5'] + $class6['6'] + $class6['7'] + $class6['8'];
                                
                                $totalClass7 = $class7['1'] + $class7['2'] + $class7['3'] + $class7['4'] + $class7['5'] + $class7['6'] + $class7['7'] + $class7['8'];
                                
                                $totalClass8 = $class8['1'] + $class8['2'] + $class8['3'] + $class8['4'] + $class8['5'] + $class8['6'] + $class8['7'] + $class8['8'];
                                
                                $totalClass9 = $class9['1'] + $class9['2'] + $class9['3'] + $class9['4'] + $class9['5'] + $class9['6'] + $class9['7'] + $class9['8'];
                                
                                $totalClass10 = $class10['1'] + $class10['2'] + $class10['3'] + $class10['4'] + $class10['5'] + $class10['6'] + $class10['7'] + $class10['8'];

                                $totalAll = $totalClass1 + $totalClass2 + $totalClass3 + $totalClass4 + $totalClass5 + $totalClass6 + $totalClass7 + $totalClass8 + $totalClass9 + $totalClass10;

                                
                            ?>
                            <tbody>
                                <tr>
                                    <td>000-099</td>
                                    <td>GEN</td>
                                    <td><?php echo ($class1['1'])?></td>
                                    <td><?php echo ($class1['2'])?></td>
                                    <td><?php echo ($class1['3'])?></td>
                                    <td><?php echo ($class1['4'])?></td>
                                    <td><?php echo ($class1['5'])?></td>
                                    <td><?php echo ($class1['6'])?></td>
                                    <td><?php echo ($class1['7'])?></td>
                                    <td><?php echo ($class1['8'])?></td>
                                    <td><?php echo $totalClass1?></td>
                                    <td><?php echo round(($totalClass1/$totalAll)*100, 2)?>%</td>
                                </tr>
                                <tr>
                                    <td>100-199</td>
                                    <td>PYS/PHILO</td>
                                    <td><?php echo ($class2['1'])?></td>
                                    <td><?php echo ($class2['2'])?></td>
                                    <td><?php echo ($class2['3'])?></td>
                                    <td><?php echo ($class2['4'])?></td>
                                    <td><?php echo ($class2['5'])?></td>
                                    <td><?php echo ($class2['6'])?></td>
                                    <td><?php echo ($class2['7'])?></td>
                                    <td><?php echo ($class2['8'])?></td>
                                    <td><?php echo $totalClass2?></td>
                                    <td><?php echo round(($totalClass2/$totalAll)*100, 2)?>%</td>
                                </tr>
                                <tr>
                                    <td>200-299</td>
                                    <td>RELIGION</td>
                                    <td><?php echo ($class3['1'])?></td>
                                    <td><?php echo ($class3['2'])?></td>
                                    <td><?php echo ($class3['3'])?></td>
                                    <td><?php echo ($class3['4'])?></td>
                                    <td><?php echo ($class3['5'])?></td>
                                    <td><?php echo ($class3['6'])?></td>
                                    <td><?php echo ($class3['7'])?></td>
                                    <td><?php echo ($class3['8'])?></td>
                                    <td><?php echo $totalClass3?></td>
                                    <td><?php echo round(($totalClass3/$totalAll)*100, 2)?>%</td>
                                </tr>
                                <tr>
                                    <td>300-399</td>
                                    <td>SOC SCI</td>
                                    <td><?php echo ($class4['1'])?></td>
                                    <td><?php echo ($class4['2'])?></td>
                                    <td><?php echo ($class4['3'])?></td>
                                    <td><?php echo ($class4['4'])?></td>
                                    <td><?php echo ($class4['5'])?></td>
                                    <td><?php echo ($class4['6'])?></td>
                                    <td><?php echo ($class4['7'])?></td>
                                    <td><?php echo ($class4['8'])?></td>
                                    <td><?php echo $totalClass4?></td>
                                    <td><?php echo round(($totalClass4/$totalAll)*100, 2)?>%</td>
                                </tr>
                                <tr>
                                    <td>400-499</td>
                                    <td>LANG</td>
                                    <td><?php echo ($class5['1'])?></td>
                                    <td><?php echo ($class5['2'])?></td>
                                    <td><?php echo ($class5['3'])?></td>
                                    <td><?php echo ($class5['4'])?></td>
                                    <td><?php echo ($class5['5'])?></td>
                                    <td><?php echo ($class5['6'])?></td>
                                    <td><?php echo ($class5['7'])?></td>
                                    <td><?php echo ($class5['8'])?></td>
                                    <td><?php echo $totalClass5?></td>
                                    <td><?php echo round(($totalClass5/$totalAll)*100, 2)?>%</td>
                                </tr>
                                <tr>
                                    <td>500-599</td>
                                    <td>PURE SCI</td>
                                    <td><?php echo ($class6['1'])?></td>
                                    <td><?php echo ($class6['2'])?></td>
                                    <td><?php echo ($class6['3'])?></td>
                                    <td><?php echo ($class6['4'])?></td>
                                    <td><?php echo ($class6['5'])?></td>
                                    <td><?php echo ($class6['6'])?></td>
                                    <td><?php echo ($class6['7'])?></td>
                                    <td><?php echo ($class6['8'])?></td>
                                    <td><?php echo $totalClass6?></td>
                                    <td><?php echo round(($totalClass6/$totalAll)*100, 2)?>%</td>
                                </tr>
                                <tr>
                                    <td>600-699</td>
                                    <td>APP SCI</td>
                                    <td><?php echo ($class7['1'])?></td>
                                    <td><?php echo ($class7['2'])?></td>
                                    <td><?php echo ($class7['3'])?></td>
                                    <td><?php echo ($class7['4'])?></td>
                                    <td><?php echo ($class7['5'])?></td>
                                    <td><?php echo ($class7['6'])?></td>
                                    <td><?php echo ($class7['7'])?></td>
                                    <td><?php echo ($class7['8'])?></td>
                                    <td><?php echo $totalClass7?></td>
                                    <td><?php echo round(($totalClass7/$totalAll)*100, 2)?>%</td>
                                </tr>
                                <tr>
                                    <td>700-799</td>
                                    <td>FA/RECRE</td>
                                    <td><?php echo ($class8['1'])?></td>
                                    <td><?php echo ($class8['2'])?></td>
                                    <td><?php echo ($class8['3'])?></td>
                                    <td><?php echo ($class8['4'])?></td>
                                    <td><?php echo ($class8['5'])?></td>
                                    <td><?php echo ($class8['6'])?></td>
                                    <td><?php echo ($class8['7'])?></td>
                                    <td><?php echo ($class8['8'])?></td>
                                    <td><?php echo $totalClass8?></td>
                                    <td><?php echo round(($totalClass8/$totalAll)*100, 2)?>%</td>
                                </tr>
                                <tr>
                                    <td>800-899</td>
                                    <td>LIT/RHETO</td>
                                    <td><?php echo ($class9['1'])?></td>
                                    <td><?php echo ($class9['2'])?></td>
                                    <td><?php echo ($class9['3'])?></td>
                                    <td><?php echo ($class9['4'])?></td>
                                    <td><?php echo ($class9['5'])?></td>
                                    <td><?php echo ($class9['6'])?></td>
                                    <td><?php echo ($class9['7'])?></td>
                                    <td><?php echo ($class9['8'])?></td>
                                    <td><?php echo $totalClass9?></td>
                                    <td><?php echo round(($totalClass9/$totalAll)*100, 2)?>%</td>
                                </tr>
                                <tr>
                                    <td>900-999</td>
                                    <td>HIST/GEO</td>
                                    <td><?php echo ($class10['1'])?></td>
                                    <td><?php echo ($class10['2'])?></td>
                                    <td><?php echo ($class10['3'])?></td>
                                    <td><?php echo ($class10['4'])?></td>
                                    <td><?php echo ($class10['5'])?></td>
                                    <td><?php echo ($class10['6'])?></td>
                                    <td><?php echo ($class10['7'])?></td>
                                    <td><?php echo ($class10['8'])?></td>
                                    <td><?php echo $totalClass10?></td>
                                    <td><?php echo round(($totalClass10/$totalAll)*100, 2)?>%</td>
                                </tr>
                                <tr>
                                    <td></td>
                                    <td>Total</td>
                                    <td><?php echo ($total1)?></td>
                                    <td><?php echo ($total2)?></td>
                                    <td><?php echo ($total3)?></td>
                                    <td><?php echo ($total4)?></td>
                                    <td><?php echo ($total5)?></td>
                                    <td><?php echo ($total6)?></td>
                                    <td><?php echo ($total7)?></td>
                                    <td><?php echo ($total8)?></td>
                                    <td><?php echo $totalAll?></td>
                                    <td>100%</td>
                                </tr>
                            
                            </tbody>
                        </table>
                    </div>
                    <div class="modal-footer">
                    </div>
                </div>
                </div>
            </div>
        <!--  -->

        <!-- Collection modal -->
        <div class="modal fade" id="summ_collect" tabindex="-1" aria-labelledby="summ_collectLabel" aria-hidden="true">
            <div class="modal-dialog modal-xl modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Summary of Collection</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                    <table class="table table-bordered border-dark">
                        <thead class="text-center">
                                    <tr>
                                        <th></th>
                                        <th>Cir</th>
                                        <th>Fil</th>
                                        <th>Gen.Ref CIR</th>
                                        <th>Gen.Ref FIL</th>
                                        <th>TOTAL</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php
                                    $total = $lastRowCir + $lastRowFil + $lastRowRefCir + $lastRowRefFil;
                                    $columnIndexRefFil = null;
                                    $columnIndexRefCir = null;
                                    $columnIndexCir = null;
                                    $columnIndexFil = null;
                                    $volumeValuesRefFil = 0;
                                    $volumeValuesRefCir = 0;
                                    $volumeValuesCir = 0;
                                    $volumeValuesFil = 0;

                                    

                                    $foundVolume = false;

                                    foreach ($getSheetRefFil->getRowIterator(1) as $row) {
                                        foreach ($row->getCellIterator() as $cell) {
                                            if ($cell->getValue() == "VOLUMES") {
                                                $columnIndexRefFil = $cell->getColumn();
                                                $foundVolume = true;
                                                break 2; 
                                            }
                                        }
                                    }
                                    
                                    foreach ($getSheetRefCir->getRowIterator(1) as $row) {
                                        foreach ($row->getCellIterator() as $cell) {
                                            if ($cell->getValue() == "VOLUMES") {
                                                $columnIndexRefCir = $cell->getColumn();
                                                $foundVolume = true;
                                                break 2; 
                                            }
                                        }
                                    }
                                    
                                    foreach ($getSheetCir->getRowIterator(1) as $row) {
                                        foreach ($row->getCellIterator() as $cell) {
                                            if ($cell->getValue() == "VOLUMES") {
                                                $columnIndexCir = $cell->getColumn();
                                                $foundVolume = true;
                                                break 2; 
                                            }
                                        }
                                    }
                                    
                                    foreach ($getSheetFil->getRowIterator(1) as $row) {
                                        foreach ($row->getCellIterator() as $cell) {
                                            if ($cell->getValue() == "VOLUMES") {
                                                $columnIndexFil = $cell->getColumn();
                                                $foundVolume = true;
                                                break 2; 
                                            }
                                        }
                                    }

                                    if($foundVolume == true) {
                                        for ($row = 2; $row <= $lastRowRefFil; $row++) {
                                            $cell = $getSheetRefFil->getCell($columnIndexRefFil . $row);
                                            $volumeValuesRefFil += $cell->getValue();
                                        }
                                        
                                        for ($row = 2; $row <= $lastRowRefCir; $row++) {
                                            $cell = $getSheetRefCir->getCell($columnIndexRefCir . $row);
                                            $volumeValuesRefCir += (float)$cell->getValue();
                                        }
                                        
                                        for ($row = 2; $row <= $lastRowCir; $row++) {
                                            $cell = $getSheetCir->getCell($columnIndexCir . $row);
                                            $volumeValuesCir += (float)$cell->getValue();
                                        }
                                        
                                        for ($row = 2; $row <= $lastRowFil; $row++) {
                                            $cell = $getSheetFil->getCell($columnIndexFil . $row);
                                            $volumeValuesFil += (float)$cell->getValue();
                                        }

                                        $totalVolume = $volumeValuesRefFil + $volumeValuesRefCir + $volumeValuesCir + $volumeValuesFil;

                                    }
                                    
                                    
                                ?>
                                    <tr>
                                        <td>Title</td>
                                        <td><?php echo $lastRowCir?></td>
                                        <td><?php echo $lastRowFil?></td>
                                        <td><?php echo $lastRowRefCir?></td>
                                        <td><?php echo $lastRowRefFil?></td>
                                        <td><?php echo $total?></td>
                                    </tr>   

                                    <tr>
                                        <td>%</td>
                                        <td><?php echo round(($lastRowCir/$total)*100)?>%</td>
                                        <td><?php echo round(($lastRowFil/$total)*100)?>%</td>
                                        <td><?php echo round(($lastRowRefCir/$total)*100)?>%</td>
                                        <td><?php echo round(($lastRowRefFil/$total)*100)?>%</td>
                                        <td>100%</td>
                                    </tr>
                                    
                                        <tr>
                                            <td>Volumes</td>
                                            <td><?php echo $volumeValuesCir?></td>
                                            <td><?php echo $volumeValuesFil?></td>
                                            <td><?php echo $volumeValuesRefCir?></td>
                                            <td><?php echo $volumeValuesRefFil?></td>
                                            <td><?php echo $totalVolume?></td>
                                        </tr>
                                        <tr>
                                            <td>%</td>
                                            <td><?php echo ($volumeValuesCir === 0 ? 0 : round(($volumeValuesCir / $totalVolume) * 100) . "%") ?></td>
                                            <td><?php echo ($volumeValuesFil === 0 ? 0 : round(($volumeValuesFil / $totalVolume) * 100) . "%") ?></td>
                                            <td><?php echo ($volumeValuesRefCir === 0 ? 0 : round(($volumeValuesRefCir / $totalVolume) * 100) . "%") ?></td>
                                            <td><?php echo ($volumeValuesRefFil === 0 ? 0 : round(($volumeValuesRefFil / $totalVolume) * 100) . "%") ?></td>

                                            <td><?php echo ($totalVolume === 0 ? 0 : "100%")?></td>
                                        </tr>

                                </tbody>
                        </table>
                    </div>
                    <div class="modal-footer">
                    </div>
                </div>
                </div>
            </div>
        <!--  -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
