<?php
	session_start();

	include("connection.php");
	include("function.php");

	$user_data = check_login($con);

	$sql = "select * from program";
	$query = mysqli_query($con, $sql);

	$program_list = mysqli_fetch_all($query, MYSQLI_ASSOC);

	if(isset($_POST['add_program'])) {
		$program = $_POST['program_name'];

		$sql_add = "insert into program(prog_name) values('$program')";
		$add_query = mysqli_query($con, $sql_add);

		if($add_query) {
			header("Location: index.php");
			echo "<script> alert('Done') </script>";
		} else {
			echo "<script> alert('Error') </script>";
		}
	}


?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="admin/style.css">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
	<title>Website</title>
</head>
<nav>
	<input id="nav-toggle" type="checkbox">
	<ul class="links">
		<li><a href="index.php" class="active">Dashboard</a></li>
		<li><a href="admin/enroll.php">CMap</a></li>
		<a href="" data-bs-toggle="modal" data-bs-target="#LogoutModal">Logout</a>
	</ul>
	<label for="nav-toggle" class="icon-burger">
		<div class="line"></div>
		<div class="line"></div>
		<div class="line"></div>
	</label>
</nav>
<body style="background-color: #e9e2c7;">
	<div class="modal fade" id="LogoutModal" tabindex="-1" aria-labelledby="LogoutModalLabel" aria-hidden="true">
	  <div class="modal-dialog modal-dialog-centered">
	    <div class="modal-content">
	      <div class="modal-header">
	        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
	      </div>
	      <div class="modal-body">
	      	<div class="text-center">
	      		<h6>Do you wanna Logout?</h6>
	      		<a href="logout.php" class="edit_btn">Yes</a>
	      	</div>
	      </div>
	      <div class="modal-footer">
	      </div>
	    </div>
	  </div>
	</div>
	<div class="container">
		<div>
			<h1></h1>
		</div>
	</div>
	<div class="container">
		<h4>Dashboard</h4>
		<div class="dash">
			<div class="row">
				<!-- teacher -->
				<div class="column">
					<div class="dash-col ">
						<a href="" data-bs-toggle="modal" data-bs-target="#programsModal">
						<h1>Programs</h1>
						<h6>List of Programs</h6></a>
					</div>
				</div>
				<!--  -->
				
				<!-- general -->
				<div class="column">
					<div class="dash-col">
						<a href="" data-bs-toggle="modal" data-bs-target="#generalModal">
						<h1>General Collection</h1>
						<h6>General Collection</h6></a>
					</div>
				</div>
				<!--  -->

				<!-- programs modal -->
				<div class="modal fade" id="programsModal" tabindex="-1" aria-labelledby="programsModalLabel" aria-hidden="true">
				  <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
				    <div class="modal-content">
				      <div class="modal-header">
				        <h1 class="modal-title fs-5" id="exampleModalLabel">Programs' Lists</h1>
				        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
				      </div>
				      <div class="modal-body">

				      	<table class="table">
				      		<thead>
					      		<tr>
					      			<th>Program </th>
					      			<th>Action</th>
					      		</tr>
				      		</thead>
				      		 <tbody class="table-group-divider">
				      			<!-- Programs Table List -->
								<?php foreach ($program_list as $p_result) { ?>
									<tr>
										<td><?php echo htmlspecialchars($p_result['prog_name'])?></td>
										<td>
										<a href="del.php?del=<?php echo htmlspecialchars($p_result['prog_id'])?>" type="button" class="edit_btn" >Delete</a>
									</td>
									</tr>
								<?php }?>
				      		</tbody>
				      	</table>
				    	</div>
				      <div class="modal-footer">
					  <a href="" type="button" class="edit_btn" data-bs-toggle="modal" data-bs-target="#addSModal">Add Program</a>
				      </div>
				    </div>
				  </div>
				</div>
				<!--  -->

				<!-- adding of programs modal -->
				<div class="modal fade" id="addSModal" tabindex="-1" aria-labelledby="addSModalLabel" aria-hidden="true">
				  <div class="modal-dialog modal-dialog-centered">
				    <div class="modal-content">
				      <div class="modal-header">
				        <h1 class="modal-title fs-5" id="exampleModalLabel">Add Programs</h1>
				        <button type="button" class="btn-close" data-bs-toggle="modal" data-bs-target="#programsModal"></button>
				      </div>
				      <div class="modal-body">
				      	<form method="POST">
                            <div class="mb-3">
                                <label>Program Name</label>
                                <input type="text" name="program_name" class="form-control">
                            </div>
                            <div class="card-footer">
                            	<button type="submit" name="add_program" class="btn btn-primary float-end">
                                    Add
                                </button>
                            	<br><br><br>
                            </div>
                        </form>
				      </div>
				      <div class="modal-footer">
				      </div>
				    </div>
				  </div>
				</div>
				<!--  -->

				<!-- general modal -->
				<div class="modal fade" id="generalModal" tabindex="-1" aria-labelledby="generalModalLabel" aria-hidden="true">
				  <div class="modal-dialog modal-dialog-centered">
				    <div class="modal-content">
				      <div class="modal-header">
				        <h1 class="modal-title fs-5" id="exampleModalLabel">General Collection</h1>
				        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
				      </div>
				      <div class="modal-body">
				      	<div class="text-center">
				      		<form action="excel_read.php" method="post" enctype="multipart/form-data">
								<input type="file" name="excel_file" id="excel_file">
								<input type="submit" value="Upload Excel File" name="fileUpload">
							</form>
				      	</div>
				      </div>
				      <div class="modal-footer">
				      </div>
				    </div>
				  </div>
				</div>
				<!--  -->
			</div>	
		</div>
	</div>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
</body>
</html>