<?php


require_once 'classes/PHPExcel/IOFactory.php';

if(isset($_FILES['excel_file']) && !empty($_FILES['excel_file']['tmp_name'])) {
    
    $excelOject = PHPExcel_IOFactory::load($_FILES['excel_file']['tmp_name']);
    $getSheetFil = $excelOject->getSheetByName("Fil.");
    $getSheetCir = $excelOject->getSheetByName("Cir.");
    $getSheetRefFil = $excelOject->getSheetByName("Ref. Fil.");
    $getSheetRefCir = $excelOject->getSheetByName("Ref. Cir.");

    $lastRowFil = $getSheetFil->getHighestRow();
    $lastRowCir = $getSheetCir->getHighestRow();
    $lastRowRefFil = $getSheetRefFil->getHighestRow();
    $lastRowRefCir = $getSheetRefCir->getHighestRow();

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <title>Document</title>
</head>
<body>
<table class="table table-bordered border-dark">
                            <thead class="text-center">
                                <tr>
                                    <th colspan="2">Course</th>
                                    <th colspan="8">Books</th>
                                    <th>Total</th>
                                    <th> % </th>
                                </tr>
                                <tr>
                                    <th>Class No.</th>
                                    <th>Class</th>
                                    <th colspan="2">Fil</th>
                                    <th colspan="2">Cir</th>
                                    <th colspan="2">Gen.Ref Fil</th>
                                    <th colspan="2">Gen.Ref Cir</th>
                                    <th></th>
                                    <th></th>
                                </tr>
                                <tr>
                                    <th></th>
                                    <th></th>
                                    <th>Title</th>
                                    <th>Volume</th>
                                    <th>Title</th>
                                    <th>Volume</th>
                                    <th>Title</th>
                                    <th>Volume</th>
                                    <th>Title</th>
                                    <th>Volume</th>
                                    <th></th>
                                    <th></th>
                                </tr>
                            </thead>

                            <?php
                                $columnIndexRefFil = null;
                                $columnIndexRefCir = null;
                                $columnIndexCir = null;
                                $columnIndexFil = null;
                                $columnIndexRefFil1 = null;
                                $columnIndexRefCir1 = null;
                                $columnIndexCir1 = null;
                                $columnIndexFil1 = null;
                                $class1 = array('1'=>0.0, '2'=>0.0, '3'=>0.0, '4'=>0.0, '5'=>0.0, '6'=>0.0, '7'=>0.0, '8'=>0.0);
                                $class2 = array('1'=>0.0, '2'=>0.0, '3'=>0.0, '4'=>0.0, '5'=>0.0, '6'=>0.0, '7'=>0.0, '8'=>0.0);
                                $class3 = array('1'=>0.0, '2'=>0.0, '3'=>0.0, '4'=>0.0, '5'=>0.0, '6'=>0.0, '7'=>0.0, '8'=>0.0);
                                $class4 = array('1'=>0.0, '2'=>0.0, '3'=>0.0, '4'=>0.0, '5'=>0.0, '6'=>0.0, '7'=>0.0, '8'=>0.0);

                                
                                foreach ($getSheetCir->getRowIterator(1) as $row) {
                                    foreach ($row->getCellIterator() as $cell) {
                                        if ($cell->getValue() == "CLASS NO.") {
                                            $columnIndexCir = $cell->getColumn();
                                        }elseif ($cell->getValue() == "VOLUMES") {
                                            $columnIndexCir1 = $cell->getColumn();
                                        }
                                    }
                                }

                                foreach ($getSheetFil->getRowIterator(1) as $row) {
                                    foreach ($row->getCellIterator() as $cell) {
                                        if ($cell->getValue() == "CLASS NO.") {
                                            $columnIndexFil = $cell->getColumn();
                                        }elseif ($cell->getValue() == "VOLUMES") {
                                            $columnIndexFil1 = $cell->getColumn();
                                        }
                                    }
                                }
                                

                                if ($columnIndexFil) {
                                    for ($row = 2; $row <= $lastRowFil; $row++) {
                                        $cell = $getSheetFil->getCell($columnIndexFil . $row);
                                        $cell1 = $getSheetFil->getCell($columnIndexFil1 . $row);
                                        $cellValue = $cell->getValue(); // Get the cell value
                                        $cellVolume = $cell1->getValue();
                                
                                        if ((float)$cellValue >= 0.0 && (float)$cellValue <= 99.0) {
                                            $class1['1'] += 1;
                                            $class1['2'] += (int)$cellVolume;
                                        }
                                        elseif ((float)$cellValue >= 100.0 && (float)$cellValue <= 199.0) {
                                            $class2['1'] += 1;
                                            $class2['2'] += (int)$cellVolume;
                                        }
                                    }
                                }

                                if ($columnIndexCir) {
                                    for ($row = 2; $row <= $lastRowCir; $row++) {
                                        $cell = $getSheetCir->getCell($columnIndexCir . $row);
                                        $cell1 = $getSheetCir->getCell($columnIndexCir1 . $row);
                                        $cellValue = $cell->getValue(); // Get the cell value
                                        $cellVolume = $cell1->getValue();
                                
                                        if ((float)$cellValue >= 0.0 && (float)$cellValue <= 99.0) {
                                            $class1['3'] += 1;
                                            $class1['4'] += (int)$cellVolume;
                                        }
                                    }
                                }

                                if ($columnIndexRefFil) {
                                    for ($row = 2; $row <= $lastRowRefFil; $row++) {
                                        $cell = $getSheetRefFil->getCell($columnIndexRefFil . $row);
                                        $cell1 = $getSheetRefFil->getCell($columnIndexRefFil1 . $row);
                                        $cellValue = $cell->getValue(); // Get the cell value
                                        $cellVolume = $cell1->getValue();
                                
                                        if ((float)$cellValue >= 0.0 && (float)$cellValue <= 99.0) {
                                            $class1['5'] += 1;
                                            $class1['6'] += (int)$cellVolume;
                                        }
                                    }
                                }
                                
                                if ($columnIndexRefCir) {
                                    for ($row = 2; $row <= $lastRowRefCir; $row++) {
                                        $cell = $getSheetRefCir->getCell($columnIndexRefCir . $row);
                                        $cell1 = $getSheetRefCir->getCell($columnIndexRefCir1 . $row);
                                        $cellValue = $cell->getValue(); // Get the cell value
                                        $cellVolume = $cell1->getValue();
                                
                                        if ((float)$cellValue >= 0.0 && (float)$cellValue <= 99.0) {
                                            $class1['7'] += 1;
                                            $class1['8'] += (int)$cellVolume;
                                        }
                                    }
                                }
                            ?>
                            <tbody>
                                <tr>
                                    <td>000-099</td>
                                    <td>GEN</td>
                                    <td><?php echo $class1['1'] ?></td>
                                    <td><?php echo $class1['2'] ?></td>
                                    <td><?php echo $class1['3'] ?></td>
                                    <td><?php echo $class1['4'] ?></td>
                                    <td><?php echo $class1['5'] ?></td>
                                    <td><?php echo $class1['6'] ?></td>
                                    <td><?php echo $class1['7'] ?></td>
                                    <td><?php echo $class1['8'] ?></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <td>100-199</td>
                                    <td>Philo</td>
                                    <td><?php echo $class2['1'] ?></td>
                                    <td><?php echo $class2['2'] ?></td>
                                    <td><?php echo $class2['3'] ?></td>
                                    <td><?php echo $class2['4'] ?></td>
                                    <td><?php echo $class2['5'] ?></td>
                                    <td><?php echo $class2['6'] ?></td>
                                    <td><?php echo $class2['7'] ?></td>
                                    <td><?php echo $class2['8'] ?></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <td>200-299</td>
                                    <td>Philo</td>
                                    <td><?php echo $class3['1'] ?></td>
                                    <td><?php echo $class3['2'] ?></td>
                                    <td><?php echo $class3['3'] ?></td>
                                    <td><?php echo $class3['4'] ?></td>
                                    <td><?php echo $class3['5'] ?></td>
                                    <td><?php echo $class3['6'] ?></td>
                                    <td><?php echo $class3['7'] ?></td>
                                    <td><?php echo $class3['8'] ?></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <td>300-399</td>
                                    <td>Philo</td>
                                    <td><?php echo $class4['1'] ?></td>
                                    <td><?php echo $class4['2'] ?></td>
                                    <td><?php echo $class4['3'] ?></td>
                                    <td><?php echo $class4['4'] ?></td>
                                    <td><?php echo $class4['5'] ?></td>
                                    <td><?php echo $class4['6'] ?></td>
                                    <td><?php echo $class4['7'] ?></td>
                                    <td><?php echo $class4['8'] ?></td>
                                    <td></td>
                                </tr>
                            </tbody>
                        </table>
</body>
</html>



<!-- <tbody>
                                <tr>
                                    <td>000-099</td>
                                    <td>GEN</td>
                                    <td><?php echo ($class1['0'])?></td>
                                    <td><?php echo ($class1['1'])?></td>
                                    <td><?php echo ($class1[2])?></td>
                                    <td><?php echo ($class1[3])?></td>
                                    <td><?php echo ($class1[4])?></td>
                                    <td><?php echo ($class1[5])?></td>
                                    <td><?php echo ($class1[6])?></td>
                                    <td><?php echo ($class1[7])?></td>
                                    <td><?php echo $totalClass1?></td>
                                    <td><?php echo ($totalClass1 === 0 ? 0 : round(($totalClass1/$total)*100))?>%</td>
                                </tr>
                                <tr>
                                    <td>100-199</td>
                                    <td>PYS/PHILO</td>
                                    <td><?php echo ($class2['0'])?></td>
                                    <td><?php echo ($class2[1])?></td>
                                    <td><?php echo ($class2[2])?></td>
                                    <td><?php echo ($class2[3])?></td>
                                    <td><?php echo ($class2[4])?></td>
                                    <td><?php echo ($class2[5])?></td>
                                    <td><?php echo ($class2[6])?></td>
                                    <td><?php echo ($class2[7])?></td>
                                    <td><?php echo $totalClass2?></td>
                                    <td><?php echo ($totalClass2 === 0 ? 0 : round(($totalClass2/$total)*100))?>%</td>
                                </tr>
                                <tr>
                                    <td>200-299</td>
                                    <td>RELIGION</td>
                                    <td><?php echo ($class3['0'])?></td>
                                    <td><?php echo ($class3[1])?></td>
                                    <td><?php echo ($class3[2])?></td>
                                    <td><?php echo ($class3[3])?></td>
                                    <td><?php echo ($class3[4])?></td>
                                    <td><?php echo ($class3[5])?></td>
                                    <td><?php echo ($class3[6])?></td>
                                    <td><?php echo ($class3[7])?></td>
                                    <td><?php echo $totalClass3?></td>
                                    <td><?php echo ($totalClass3 === 0 ? 0 : round(($totalClass3/$total)*100))?>%</td>
                                </tr>
                                <tr>
                                    <td>300-399</td>
                                    <td>SOC SCI</td>
                                    <td><?php echo ($class4['0'])?></td>
                                    <td><?php echo ($class4[1])?></td>
                                    <td><?php echo ($class4[2])?></td>
                                    <td><?php echo ($class4[3])?></td>
                                    <td><?php echo ($class4[4])?></td>
                                    <td><?php echo ($class4[5])?></td>
                                    <td><?php echo ($class4[6])?></td>
                                    <td><?php echo ($class4[7])?></td>
                                    <td><?php echo $totalClass4?></td>
                                    <td><?php echo ($totalClass4 === 0 ? 0 : round(($totalClass4/$total)*100))?>%</td>
                                </tr>
                                <tr>
                                    <td>400-499</td>
                                    <td>LANG</td>
                                    <td><?php echo ($class5['0'])?></td>
                                    <td><?php echo ($class5[1])?></td>
                                    <td><?php echo ($class5[2])?></td>
                                    <td><?php echo ($class5[3])?></td>
                                    <td><?php echo ($class5[4])?></td>
                                    <td><?php echo ($class5[5])?></td>
                                    <td><?php echo ($class5[6])?></td>
                                    <td><?php echo ($class5[7])?></td>
                                    <td><?php echo $totalClass5?></td>
                                    <td><?php echo ($totalClass5 === 0 ? 0 : round(($totalClass5/$total)*100))?>%</td>
                                </tr>
                                <tr>
                                    <td>500-599</td>
                                    <td>PURE SCI</td>
                                    <td><?php echo ($class6['0'])?></td>
                                    <td><?php echo ($class6[1])?></td>
                                    <td><?php echo ($class6[2])?></td>
                                    <td><?php echo ($class6[3])?></td>
                                    <td><?php echo ($class6[4])?></td>
                                    <td><?php echo ($class6[5])?></td>
                                    <td><?php echo ($class6[6])?></td>
                                    <td><?php echo ($class6[7])?></td>
                                    <td><?php echo $totalClass6?></td>
                                    <td><?php echo ($totalClass6 === 0 ? 0 : round(($totalClass6/$total)*100))?>%</td>
                                </tr>
                                <tr>
                                    <td>600-699</td>
                                    <td>APP SCI</td>
                                    <td><?php echo ($class7['0'])?></td>
                                    <td><?php echo ($class7[1])?></td>
                                    <td><?php echo ($class7[2])?></td>
                                    <td><?php echo ($class7[3])?></td>
                                    <td><?php echo ($class7[4])?></td>
                                    <td><?php echo ($class7[5])?></td>
                                    <td><?php echo ($class7[6])?></td>
                                    <td><?php echo ($class7[7])?></td>
                                    <td><?php echo $totalClass7?></td>
                                    <td><?php echo ($totalClass7 === 0 ? 0 : round(($totalClass7/$total)*100))?>%</td>
                                </tr>
                                <tr>
                                    <td>700-799</td>
                                    <td>FA/RECRE</td>
                                    <td><?php echo ($class8['0'])?></td>
                                    <td><?php echo ($class8[1])?></td>
                                    <td><?php echo ($class8[2])?></td>
                                    <td><?php echo ($class8[3])?></td>
                                    <td><?php echo ($class8[4])?></td>
                                    <td><?php echo ($class8[5])?></td>
                                    <td><?php echo ($class8[6])?></td>
                                    <td><?php echo ($class8[7])?></td>
                                    <td><?php echo $totalClass8?></td>
                                    <td><?php echo ($totalClass8 === 0 ? 0 : round(($totalClass8/$total)*100))?>%</td>
                                </tr>
                                <tr>
                                    <td>800-899</td>
                                    <td>LIT/RHETO</td>
                                    <td><?php echo ($class9['0'])?></td>
                                    <td><?php echo ($class9[1])?></td>
                                    <td><?php echo ($class9[2])?></td>
                                    <td><?php echo ($class9[3])?></td>
                                    <td><?php echo ($class9[4])?></td>
                                    <td><?php echo ($class9[5])?></td>
                                    <td><?php echo ($class9[6])?></td>
                                    <td><?php echo ($class9[7])?></td>
                                    <td><?php echo $totalClass9?></td>
                                    <td><?php echo ($totalClass9 === 0 ? 0 : round(($totalClass9/$total)*100))?>%</td>
                                </tr>
                                <tr>
                                    <td>900-999</td>
                                    <td>HIST/GEO</td>
                                    <td><?php echo ($class10['0'])?></td>
                                    <td><?php echo ($class10[1])?></td>
                                    <td><?php echo ($class10[2])?></td>
                                    <td><?php echo ($class10[3])?></td>
                                    <td><?php echo ($class10[4])?></td>
                                    <td><?php echo ($class10[5])?></td>
                                    <td><?php echo ($class10[6])?></td>
                                    <td><?php echo ($class10[7])?></td>
                                    <td><?php echo $totalClass10?></td>
                                    <td><?php echo ($totalClass10 === 0 ? 0 : round(($totalClass10/$total)*100))?>%</td>
                                </tr> -->





                                <!-- $sql = "SELECT COUNT(*) FROM c_map WHERE curricul_sub = '$sub' AND class = 'Circulation'";
                                $run_title = mysqli_query($con, $sql);

                                $titleRow = mysqli_fetch_assoc($run_title);
                                $titleCount = $titleRow['COUNT(*)']; // Get the count from the result

                                $title = $list['title'];
                                if(in_array($title, $titles)) {
                                    
                                }
                                if (!isset($titles[$title])) {
                                    $titles[$title] = 0; // Initialize the title count if it's not set
                                    $totalCopies[$title] = 0; // Initialize the total copies for the title
                                }
                                $titles[$title]++;
                                $totalCopies[$title] += $list['no_copies'];

                                $sql2 = "SELECT COUNT(*) FROM c_map WHERE curricul_sub = '$sub' AND class = 'Filipiniana'";
                                $run_title2 = mysqli_query($con, $sql2);

                                $titleRow2 = mysqli_fetch_assoc($run_title2);

                                $titleCount2 = $titleRow2['COUNT(*)']; // Get the count from the result

                                $title2 = $list['title'];
                                if (!isset($titlesFil[$title2])) {
                                    $titlesFil[$title2] = 0; // Initialize the title count if it's not set
                                    $totalCopiesFil[$title2] = 0; // Initialize the total copies for the title
                                }
                                $titlesFil[$title2]++;
                                $totalCopiesFil[$title2] += $list['no_copies']; -->